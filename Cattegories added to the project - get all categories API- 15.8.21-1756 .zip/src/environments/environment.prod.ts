export const environment = {
  production: true,

  productsUrl: "http://www.mysite.com/api/products/",
  productsUrlDelayed: "http://www.mysite.com/api/products/delayed/",
  productImagesUrl: "http://www.mysite.com/api/products/images/",
  employeesUrl: "http://mysite/api/employees/",
  employeeImagesUrl: "http://mysite/api/employees/images/"

};
