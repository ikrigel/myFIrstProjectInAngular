export class UserModel {
    public id: number;
    public firstName: string;
    public lastName: string;
    public username: string;
    public password: string;
    public token: string;
    public isAdmin: boolean;
}
